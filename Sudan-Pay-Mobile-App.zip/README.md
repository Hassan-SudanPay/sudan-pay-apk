# Sudan Pay mobile application

Cross-platform Expo/React Native application for Android and iOS.

## Included

- Arabic mobile-first UI
- Mobile/email sign-in flow and demo OTP (`482913`)
- Secure session storage
- Device biometric confirmation before transactions
- Balance inquiry, airtime transfer, mobile bill payment and electricity purchase
- Transaction history, provider references and electricity-token receipt
- Idempotency keys on every transaction
- Mock mode for demonstrations

## Run

Install Node.js 22+, then run `npm install` and `npm start`. Scan the QR code with Expo Go.

## Production connection

`src/services/api.ts` is the only mobile networking boundary. Change `DEMO_MODE` to `false` after the production API is public. Zain credentials, signing keys, certificates, reconciliation and webhook logic remain on the backend and must never be embedded in the mobile application.

Before store release, replace sample branding, configure production API URL, enable Android Play Integrity/iOS App Attest, complete security testing, and obtain Zain and regulatory approval.

## Build an APK with GitHub

Push this project to the `main` branch. Open **Actions**, select **Build Android APK**, and run the workflow. When it succeeds, download the `sudan-pay-demo-apk` artifact. GitHub retains the demo build for 14 days.
