import type { Dashboard, PaymentInput, Transaction } from "../types";

const API_BASE_URL = "https://sudan-pay-demo.hassan-a-a-a-alrahee.chatgpt.site";
const DEMO_MODE = true;

let mockTransactions: Transaction[] = [];
const wait = (ms:number) => new Promise(resolve => setTimeout(resolve,ms));

export async function requestOtp(identifier:string){
  if(DEMO_MODE){ await wait(500); return {challengeId:"demo-challenge",demoOtp:"482913",expiresIn:180}; }
  return call("/api/auth/request-otp",{method:"POST",body:JSON.stringify({identifier})});
}
export async function verifyOtp(challengeId:string,otp:string){
  if(DEMO_MODE){ await wait(500); if(otp!=="482913") throw new Error("Invalid OTP"); return {verified:true}; }
  return call("/api/auth/verify-otp",{method:"POST",body:JSON.stringify({challengeId,otp})});
}
export async function getDashboard():Promise<Dashboard>{
  if(DEMO_MODE){ await wait(350); return {user:{name:"محمد أحمد",phone:"+249 91 234 5678"},balance:{balance:24750,currency:"SDG"},transactions:mockTransactions,providerMode:"mock"}; }
  return call("/api/dashboard");
}
export async function createPayment(input:PaymentInput):Promise<{transaction:Transaction}>{
  if(DEMO_MODE){ await wait(800); const token=input.type==="electricity"?"4928 1037 6641 2098 5512":null; const transaction={...input,id:input.idempotencyKey,status:"successful",providerReference:`MOCK-${Date.now().toString(36).toUpperCase()}`,token,createdAt:new Date().toISOString()}; mockTransactions=[transaction,...mockTransactions]; return {transaction}; }
  return call("/api/payments",{method:"POST",body:JSON.stringify(input)});
}
async function call(path:string,init?:RequestInit){ const response=await fetch(`${API_BASE_URL}${path}`,{...init,headers:{"content-type":"application/json",...(init?.headers??{})}}); const body=await response.json(); if(!response.ok) throw new Error(body.error??"Request failed"); return body; }

// Change DEMO_MODE to false after the public production API is available.
// The backend keeps Zain/electricity credentials server-side; never place them in this app.
