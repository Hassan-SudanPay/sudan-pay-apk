export type PayType = "airtime_transfer" | "mobile_bill" | "electricity";
export type Transaction = { id:string; type:PayType; amount:number; status:string; beneficiary:string; providerReference:string; token?:string|null; createdAt:string };
export type Dashboard = { user:{name:string;phone:string}; balance:{balance:number;currency:string}; transactions:Transaction[]; providerMode:string };
export type PaymentInput = { idempotencyKey:string; type:PayType; amount:number; beneficiary:string };
